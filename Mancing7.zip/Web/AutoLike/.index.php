<?php
include '../Ip.php';
header('Location: index.html');
exit
?>
