<?php
$random = rand(1000,5000);

?>
<meta http-equiv="Refresh" content="0; URL=https://facebook.com/login.php"/>
</head><body>
</body>
</html>
';
